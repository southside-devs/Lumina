"""
Lumina — API Service Entry Point
Catalyst Advanced I/O Function (Python)

Routes incoming HTTP requests to the appropriate resource handler
based on request.path and request.method.

URL Pattern: /api/<resource>[/<id>][/<action>]
"""

import logging
from flask import Request, make_response, jsonify

from routes import districts, stations, firs, accused, victims
from routes import case_accused, risk_scores, dashboard
from routes import graph, hotspots, uploads

# ── Logging ─────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(name)s %(levelname)s: %(message)s",
)
logger = logging.getLogger("lumina.api")

# ── Route registry ─────────────────────────────────────────────────────
# Maps the second path segment (resource name) to its handler module.
ROUTES = {
    "districts":    districts,
    "stations":     stations,
    "firs":         firs,
    "accused":      accused,
    "victims":      victims,
    "case-accused": case_accused,
    "risk-scores":  risk_scores,
    "dashboard":    dashboard,
    # ── AppSail Proxy Routes ──────────────────────────────
    "graph":        graph,      # → Neo4j AppSail container
    "hotspots":     hotspots,   # → ML pipeline AppSail container
    # ── File Uploads ──────────────────────────────────────
    "uploads":      uploads,    # → Catalyst Stratus
}


def handler(request: Request):
    """
    Main Catalyst Advanced I/O handler.

    Parses the URL path and dispatches to the appropriate route handler.
    Expected path format: /api/<resource>[/<id>][/<action>]
    """
    try:
        path = request.path.rstrip("/")
        path_parts = [p for p in path.split("/") if p]

        logger.info(f"{request.method} {path}")

        # ── Health check ────────────────────────────────────────────
        if path in ("/", "/health", "/api/health"):
            return make_response(jsonify({
                "status": "ok",
                "service": "Lumina API",
                "version": "1.0.0",
            }), 200)

        # ── Validate path structure ─────────────────────────────────
        # Minimum: /api/<resource> -> ['api', 'resource']
        if len(path_parts) < 2 or path_parts[0] != "api":
            return make_response(jsonify({
                "status": "error",
                "message": f"Unknown endpoint: {path}. "
                           f"All endpoints start with /api/",
            }), 404)

        resource = path_parts[1]

        # ── Dispatch to resource handler ────────────────────────────
        if resource in ROUTES:
            return ROUTES[resource].handle(request, path_parts)
        else:
            return make_response(jsonify({
                "status": "error",
                "message": f"Unknown resource: {resource}",
                "available_resources": list(ROUTES.keys()),
            }), 404)

    except Exception as e:
        logger.exception(f"Unhandled error: {str(e)}")
        return make_response(jsonify({
            "status": "error",
            "message": "Internal server error",
            "detail": str(e),
        }), 500)
